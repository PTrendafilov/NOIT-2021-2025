from django.shortcuts import render

def index():
    print('hello')