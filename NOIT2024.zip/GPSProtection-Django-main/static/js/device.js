function showDeviceForm(){
    document.getElementById("device-form-container").style.display = "block";
}

function hideDeviceForm(){
    document.getElementById("device-form-container").style.display = "none";
}

